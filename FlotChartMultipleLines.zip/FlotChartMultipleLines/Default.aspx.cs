﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    [WebMethod]
    public static List<ChartResult> GetChartData()
    {
        List<ChartResult> LstChartResData = new List<ChartResult>();
               
        ChartResult objChartRes1 = new ChartResult();
        objChartRes1.strEntryDate = (Convert.ToDateTime("25/08/2015 6:33:37 PM")).ToString("MM/dd/yyyy");
        objChartRes1.decOverload = Convert.ToDecimal(1.00);
        objChartRes1.decBrokenBar = Convert.ToDecimal(2.00);
        objChartRes1.decAudio_hf_rms = Convert.ToDecimal(3.00);
        objChartRes1.decHealth = Convert.ToDecimal(70.00);
        LstChartResData.Add(objChartRes1);

        ChartResult objChartRes2 = new ChartResult();
        objChartRes2.strEntryDate = (Convert.ToDateTime("05/09/2015 1:23:37 AM")).ToString("MM/dd/yyyy");
        objChartRes2.decOverload = Convert.ToDecimal(2.00);
        objChartRes2.decBrokenBar = Convert.ToDecimal(0.50);
        objChartRes2.decAudio_hf_rms = Convert.ToDecimal(4.00);
        objChartRes2.decHealth = Convert.ToDecimal(80.50);
        LstChartResData.Add(objChartRes2);

        ChartResult objChartRes3 = new ChartResult();
        objChartRes3.strEntryDate = (Convert.ToDateTime("15/10/2015 8:33:37 AM")).ToString("MM/dd/yyyy");
        objChartRes3.decOverload = Convert.ToDecimal(2.00);
        objChartRes3.decBrokenBar = Convert.ToDecimal(0.00);
        objChartRes3.decAudio_hf_rms = Convert.ToDecimal(4.50);
        objChartRes3.decHealth = Convert.ToDecimal(80.00);
        LstChartResData.Add(objChartRes3);

        ChartResult objChartRes4 = new ChartResult();
        objChartRes4.strEntryDate = (Convert.ToDateTime("15/10/2015 5:33:37 PM")).ToString("MM/dd/yyyy");
        objChartRes4.decOverload = Convert.ToDecimal(4.90);
        objChartRes4.decBrokenBar = Convert.ToDecimal(6.50);
        objChartRes4.decAudio_hf_rms = Convert.ToDecimal(5.70);
        objChartRes4.decHealth = Convert.ToDecimal(95.30);
        LstChartResData.Add(objChartRes4);

        ChartResult objChartRes5 = new ChartResult();
        objChartRes5.strEntryDate = (Convert.ToDateTime("02/11/2015 12:05:37 PM")).ToString("MM/dd/yyyy");
        objChartRes5.decOverload = Convert.ToDecimal(2.50);
        objChartRes5.decBrokenBar = Convert.ToDecimal(3.00);
        objChartRes5.decAudio_hf_rms = Convert.ToDecimal(6.00);
        objChartRes5.decHealth = Convert.ToDecimal(95.20);
        LstChartResData.Add(objChartRes5);

        ChartResult objChartRes6 = new ChartResult();
        objChartRes6.strEntryDate = (Convert.ToDateTime("15/12/2015 6:33:37 PM")).ToString("MM/dd/yyyy");
        objChartRes6.decOverload = Convert.ToDecimal(0.50);
        objChartRes6.decBrokenBar = Convert.ToDecimal(1.75);
        objChartRes6.decAudio_hf_rms = Convert.ToDecimal(1.50);
        objChartRes6.decHealth = Convert.ToDecimal(85.00);
        LstChartResData.Add(objChartRes6);

        ChartResult objChartRes7 = new ChartResult();
        objChartRes7.strEntryDate = (Convert.ToDateTime("16/12/2015 6:33:37 PM")).ToString("MM/dd/yyyy");
        objChartRes7.decOverload = Convert.ToDecimal(1.50);
        objChartRes7.decBrokenBar = Convert.ToDecimal(1.00);
        objChartRes7.decAudio_hf_rms = Convert.ToDecimal(2.50);
        objChartRes7.decHealth = Convert.ToDecimal(75.00);
        LstChartResData.Add(objChartRes7);

        return LstChartResData;
    }

    public class ChartResult
    {        
        public string strEntryDate { get; set; }
        public decimal decOverload { get; set; }
        public decimal decBrokenBar { get; set; }
        public decimal decAudio_hf_rms { get; set; }
        public decimal decHealth { get; set; }
    }
}