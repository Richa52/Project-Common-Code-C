﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    [WebMethod]
    public static List<string> GetLatLngData()
    {
        List<string> strLstLatLngData = new List<string>();
        try
        {
            strLstLatLngData.Add("23.031814, 72.565549");
            strLstLatLngData.Add("23.031809, 72.565598");
            strLstLatLngData.Add("23.0318, 72.5657");
            strLstLatLngData.Add("23.0318, 72.5656");
            strLstLatLngData.Add("23.0318, 72.5657");
            strLstLatLngData.Add("23.0318, 72.5656");
            strLstLatLngData.Add("23.0317, 72.5656");
            strLstLatLngData.Add("23.0318, 72.5657");
            strLstLatLngData.Add("23.0317, 72.5655");
            strLstLatLngData.Add("23.0317, 72.5656");
            strLstLatLngData.Add("23.0128, 72.5232");
            strLstLatLngData.Add("23.0087, 72.529");
            strLstLatLngData.Add("23.0155, 72.5246");
            strLstLatLngData.Add("23.0136, 72.5242");
            strLstLatLngData.Add("23.0153, 72.5246");
            strLstLatLngData.Add("23.0076, 72.5336");
            strLstLatLngData.Add("23.0155, 72.5246");
            strLstLatLngData.Add("23.0133, 72.5239");
            strLstLatLngData.Add("23.0125, 72.5235");
            strLstLatLngData.Add("23.031814, 72.565549");
            strLstLatLngData.Add("23.031809, 72.565598");
            strLstLatLngData.Add("23.0318, 72.5657");
            strLstLatLngData.Add("23.0318, 72.5656");
            strLstLatLngData.Add("23.0318, 72.5657");
            strLstLatLngData.Add("23.0318, 72.5656");
            strLstLatLngData.Add("23.0317, 72.5656");
            strLstLatLngData.Add("23.0318, 72.5657");
            strLstLatLngData.Add("23.0317, 72.5655");
            strLstLatLngData.Add("23.0317, 72.5656");
            strLstLatLngData.Add("23.0128, 72.5232");
            strLstLatLngData.Add("23.0087, 72.529");
            strLstLatLngData.Add("23.0155, 72.5246");
            strLstLatLngData.Add("23.0136, 72.5242");
            strLstLatLngData.Add("23.0153, 72.5246");
            strLstLatLngData.Add("23.0076, 72.5336");
            strLstLatLngData.Add("23.0155, 72.5246");
            strLstLatLngData.Add("23.0133, 72.5239");
            strLstLatLngData.Add("23.0125, 72.5235");  
        }
        catch (Exception ex)
        {
            
        }

        return strLstLatLngData;
    }

    [WebMethod]
    public static List<string> GetServiceProviderData()
    {
        List<string> strServiceProviderData = new List<string>();
        try
        {
            strServiceProviderData.Add("31.96,115.84,test1");
            strServiceProviderData.Add("37.566535,126.9779692,test2");
            strServiceProviderData.Add("49.4208848,1.0475243,test3");
            strServiceProviderData.Add("49.54724,8.62971,test4");
            strServiceProviderData.Add("49.64966,8.46375,test5");
            strServiceProviderData.Add("50.38007,7.58946,test6");
            strServiceProviderData.Add("50.4185928,4.9239001,test7");
            strServiceProviderData.Add("50.4267176,1.6299839,test8");
            strServiceProviderData.Add("50.9173757,5.5113355,test9");
            strServiceProviderData.Add("50.9544743,5.7828726,test10");
            strServiceProviderData.Add("51.2372145,4.3072069,test11");
            strServiceProviderData.Add("51.2400922,4.4744961,test12");
            strServiceProviderData.Add("51.26834,6.51457,test13");
            strServiceProviderData.Add("51.340402,0.731596,test14");
        }
        catch (Exception ex)
        {
            
        }

        return strServiceProviderData;
    }
}